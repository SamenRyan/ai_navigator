from django.apps import AppConfig


class NavigatorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'navigator'
