from django.urls import path
from .views import get_route
from .views import map_view

urlpatterns = [
    
    path('', map_view, name='map'),  # Opens map at http://localhost:8000/
path('route/', get_route, name='get_route'),
]

