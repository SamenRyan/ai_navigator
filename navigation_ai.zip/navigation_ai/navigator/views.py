from django.http import JsonResponse
import openrouteservice
from openrouteservice import convert
from django.shortcuts import render

client = openrouteservice.Client(key='5b3ce3597851110001cf62480f1da42a70c347eb977abedf4a2c1363')  # Replace with your key


def map_view(request):
    return render(request, 'navigator/map.html')

def get_route(request):
    try:
        start_coords = list(map(float, request.GET.get('start').split(',')))
        end_coords = list(map(float, request.GET.get('end').split(',')))

        coords = (start_coords, end_coords)

        route = client.directions(
            coords,
            profile='driving-car',
            format='geojson'
        )
        return JsonResponse(route)

    except (ValueError, TypeError):
        return JsonResponse({
            "error": "Invalid coordinates. Please provide 'lng,lat' format like: 8.681495,49.41461"
        }, status=400)
